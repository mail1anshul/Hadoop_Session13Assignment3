object SqrRootApp {
  
def squareRoot( n : Int ) : Int = {
  var x = n
  var y = 1
  var z = 0.000001	  
 
  while( x-y > z ) {
    x=(x+y)/2
    y=n/x
  } 
  return x
  }
  
  def main(args: Array[String])
  {
    println(squareRoot(121))
  }
}